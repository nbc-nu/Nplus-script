2026 N.U. corporation studios

==================================================================

N++ script basic

\------------------------------------------------------------------

N++

N.U. langueges\&programs

==================================================================

IMPORTANT! If you want N++ genuine version certify is not

an non made by nu-nbc version.

==================================================================

if you want to intall the N++ visual script editor without

unstalling N++ donwload standalone version at: 

**https://nbc-nu.github.io/Nplus-script/**

==================================================================

