@echo off
if "%1"=="" (title dualbits-minipc) else (title %1)

if "%1"=="" goto login

findstr /i /c:":%1" "%~f0" >nul
if errorlevel 1 (
    powershell -C "Write-Host '$sudo sitaxe error at "$sudo" 1 <----' -ForegroundColor red"
    echo error on command $sudo %1
    echo exit with 0
    goto :eof
)

goto %1

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: 2026 NBC corporation | N++ | N.U. script basic      ::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: by nu-nbc                                           ::
:: N++ code                                            ::
:: N++ visual script                                   ::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::

:: ok ::
:close /c/
exit
goto :eof
:: ok ::
:/c/ get 
@echo off
dir
goto :eof

:: ok ::
:localhosts/this/
@echo off
set /p HTML=html code:  
title 8000 & start /b powershell -C "$L=New-Object Net.HttpListener;$L.Prefixes.Add('http://localhost:8000/');$L.Start();while($L.IsListening){$C=$L.GetContext();$B=[Text.Encoding]::UTF8.GetBytes($env:HTML);$C.Response.OutputStream.Write($B,0,$B.Length);$C.Response.Close()}"
echo loading ports
echo donwloading /localhosts/n.u./this/8000
echo creating localport at /localhosts/8000
echo localhost defined at 8000
powershell -C "Write-Host 'Localhost created at http://localhost:8000/' -ForegroundColor Cyan"
echo runing localhost
echo sucess
goto :eof
:: ok ::
:object/new_window
@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

reg add "HKCU\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION" /v "powershell.exe" /t REG_DWORD /d 11001 /f >nul 2>&1

set "meu_html="
set /p "meu_html=HTML code: "

powershell -NoProfile -WindowStyle Hidden -Command ^
    "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" ^
    "$form = New-Object System.Windows.Forms.Form;" ^
    "$form.Text = 'N++ visual script';" ^
    "$form.WindowState = 'Maximized';" ^
    "$form.FormBorderStyle = 'Sizable';" ^
    "$form.MinimizeBox = $true;" ^
    "$form.MaximizeBox = $true;" ^
    "$browser = New-Object System.Windows.Forms.WebBrowser;" ^
    "$browser.Dock = 'Fill';" ^
    "$htmlBase = '<html><head><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\"></head><body style=\"margin:0; padding:20px; background:#ffffff; font-family:Arial;\">' + [System.Environment]::GetEnvironmentVariable('meu_html') + '</body></html>';" ^
    "$browser.DocumentText = $htmlBase;" ^
    "$form.Controls.Add($browser);" ^
    "[System.Windows.Forms.Application]::Run($form);" >nul 2>&1
goto :eof
:: ok ::
:define/var/
echo please input a var value
set /p text=$sudo define/var/
set var=%text% 
echo defined
goto :eof
:: ok ::
:show_input/var/
echo %var%
goto :eof
:: ok ::
:window_title/
set /p title=$sudo window_title/
title %title%
goto :eof
:: ok ::
:format/ports:all
taskkill /f /fi "SERVICES eq bfe" /im powershell.exe >nul 2>&1 & wmic process where "name='powershell.exe'" call terminate >nul 2>&1
echo sucess
goto :eof
:: ok ::
:localhosts/you/
:restartporttypeinterln
set /p num=port: 
echo %num%| findstr /r "^[0-9][0-9]*$" >nul
if errorlevel 1 (
    echo sitaxe error! please type numbers on the port from 0000 to 9999
    goto restartporttypeinterln
)
set /p HTML=html code:  
title 8000 & start /b powershell -C "$L=New-Object Net.HttpListener;$L.Prefixes.Add('http://localhost:%num%/');$L.Start();while($L.IsListening){$C=$L.GetContext();$B=[Text.Encoding]::UTF8.GetBytes($env:HTML);$C.Response.OutputStream.Write($B,0,$B.Length);$C.Response.Close()}"
echo loading ports
echo donwloading /localhosts/n.u./this/%num%
echo creating localport at /localhosts/%num%
echo localhost defined at %num%
echo Localhost created at http://localhost:%num%/
echo runing localhost
echo sucess
goto :eof
:: ok ::
:/c/credits/ get
echo :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
echo :: (c)2026 NBC corporation ^| N^+^+ ^| N.U. script basic   ::
echo :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
echo :: by nu-nbc                                           ::
echo :: N^+^+ code                                            ::
echo :: N^+^+ visual script                                   ::
echo :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
pause >nul
echo :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
echo :: proprieties                                         ::
echo :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
echo :: softwere .batch                                     ::
echo :: Genuine                                             ::
echo :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
goto :eof
:: ok ::
:back_color
set /p color=back_color/
if /i "%color%"=="red" color 4F
if /i "%color%"=="purple" color 5F
if /i "%color%"=="yellow" color 6F
if /i "%color%"=="light_gray" color 70
if /i "%color%"=="gray" color 8F
if /i "%color%"=="blue" color 9F
if /i "%color%"=="green" color AF
if /i "%color%"=="light_blue" color B0
if /i "%color%"=="ligth_red" color CF
if /i "%color%"=="pink" color DF
if /i "%color%"=="gold" color E0
if /i "%color%"=="black" color 0f
goto :eof
:: ok ::
:ask/question/
set /p answer=input:
goto :eof
:: ok ::
:ask_set/var/
var=%answer%
goto :eof
:: ok ::
:confirm
@echo off
chcp 65001 >nul
echo Dim resposta > "%temp%\janela.vbs"
echo resposta = MsgBox("Confirm", 4 + 32, "N++ visual script") >> "%temp%\janela.vbs"
echo If resposta = 6 Then WScript.Quit(0) Else WScript.Quit(1) >> "%temp%\janela.vbs"

wscript "%temp%\janela.vbs"

if %errorlevel%==0 (
    echo confirm
) else (
    exit
)
del "%temp%\janela.vbs" >nul 2>&1
goto :eof
:: ok ::
:/print/
set /p print=$sudo /print/
echo %print%
goto :eof

:help
taskkill /f /fi "SERVICES eq bfe" /im powershell.exe >nul 2>&1 & wmic process where "name='powershell.exe'" call terminate >nul 2>&1
set HTML=^<h1^>N++ Help Guide^</h1^>^<pre^>Command list for help:^</pre^>^<hr /^>^<pre^>N++ help list (c)2026^<br^>$sudo ^| you need to put on evry line. Ex: $sudo /print/hello^<br^>/print/ ^| display the text you typed^<br^>/c/ get ^| show all your files^<br^>close /c/ ^| close N++^<br^>object/new_window ^| opens an window on your screen with an HTML^<br^>localhosts/this/ ^| creates an HTTP local protocol. Ex: http://localhost:8000^<br^>localhosts/you/ ^| permit you to select your number on your http protocol. Ex: http://localhost:1234 ^<--- you can change^<br^>format/ports:all ^| delet all your localhosts on your PC^<br^>define/var/ ^| creates an variable called var and save an value^<br^>show_input/var/ ^| show the variable value^<br^>window_title/ ^| defines the title of your window^<br^>/c/credits/ get ^| open the credits^<br^>back_color ^| define the background color^<br^>confirm ^| asks the user yes or no.^<br^>ask_set/var/ ^| set the variable var to the answer^<br^>ask/question ^| asks something to the user, and store the answer in "answer" variable^<br^>help ^| give an guide site to open. (this one you´re seeing) mostly http://localhost:1111/^</pre^>^<hr /^>
start /b powershell -C "$L=New-Object Net.HttpListener;$L.Prefixes.Add('http://localhost:1111/');$L.Start();while($L.IsListening){$C=$L.GetContext();$B=[Text.Encoding]::UTF8.GetBytes($env:HTML);$C.Response.OutputStream.Write($B,0,$B.Length);$C.Response.Close()}"
powershell -C "Write-Host 'acess http://localhost:1111/ for help' -ForegroundColor green"
goto :eof